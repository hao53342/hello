$(function() {
	"use strict";
	
	
	    tinymce.init({
		  selector: '#mytextarea'
		});
	
	
	});