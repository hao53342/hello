package com.czw.pay.dao;

import org.springframework.stereotype.Repository;

import com.czw.common.dao.BaseDao;
import com.czw.pay.entity.JpayOrder;

/**
 * @author 崔志伟
 * 联系方式：493067123@qq.com
 * 创建日期：2017年12月4日
 * www.cuizhiwei.com
 */
@Repository
public class JpayOrderDao extends BaseDao<JpayOrder>{

}
